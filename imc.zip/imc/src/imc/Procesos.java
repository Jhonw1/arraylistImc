package imc;

import java.util.ArrayList;

import javax.swing.JOptionPane;

public class Procesos {

	String nombre = "";
	double imc, peso, talla;
	ArrayList<String> nombresList;
	ArrayList<Double> pesoList;
	ArrayList<Double> tallaList;
	ArrayList<String> resultadosList;

	public Procesos() {
		nombresList = new ArrayList<String>();
		resultadosList = new ArrayList<String>();
		pesoList = new ArrayList<Double>();
		tallaList = new ArrayList<Double>();
		menu();
	}

	public void menu() {
		int opcion;
		do {
			opcion = Integer.parseInt(
					JOptionPane.showInputDialog("1.ingresar datos\n" + " 2.consultar IMC\n" + " 3.mostrar lista\n"
							+ " 4.Buscar por nombre\n" + " 5.Actualizar\n" + " 6.salir\n"));
			iniciar(opcion);
		} while (opcion != 6);
	}

	public void iniciar(int opcion) {
		switch (opcion) {
		case 1:
			ingresarDatos();
			break;
		case 2:
			if (!nombresList.isEmpty()) {
				calcularIMC();
			}else {
				JOptionPane.showMessageDialog(null, "debe llenar los datos. opcion :1");
			}
			break;
		case 3:
			if (!nombresList.isEmpty()) {
				imprimirListas();
			}else {
				JOptionPane.showMessageDialog(null, "debe llenar los datos. opcion :1");
			}
			break;
		case 4:
			if (!nombresList.isEmpty()) {
				consultarPorNombre();
			}else {
				JOptionPane.showMessageDialog(null, "debe llenar los datos. opcion :1");
			}
			break;
		case 5:
			if (!nombresList.isEmpty()) {
				actualizar();
			}else {
				JOptionPane.showMessageDialog(null, "debe llenar los datos. opcion :1");
			}
			break;
		case 6:
				JOptionPane.showMessageDialog(null, "salio del programa");
			break;
			
		default:
				JOptionPane.showMessageDialog(null, "ingrese un numero valido");
			break;
		}
	}

	private void actualizar() {
		String persona = JOptionPane.showInputDialog("ingrese el nombre que desea actualizar");
		String opcion;
		String nuevoDato;
		double nuevoDatoDouble;

		for (int i = 0; i < nombresList.size(); i++) {
			if (nombresList.get(i).equals(persona)) {
				opcion = JOptionPane.showInputDialog("ingrese que desea actualizar: nombre, peso, talla");
				if (opcion.equals("nombre")) {
					nuevoDato = JOptionPane.showInputDialog("ingrese el nuevo nombre");
					nombresList.set(i, nuevoDato);
				} else if (opcion.equals("peso")) {
					nuevoDatoDouble = Double.parseDouble(JOptionPane.showInputDialog("ingrese el nuevo peso"));
					pesoList.set(i, nuevoDatoDouble);
				} else if (opcion.equals("talla")) {
					nuevoDatoDouble = Double.parseDouble(JOptionPane.showInputDialog("ingrese la nueva talla"));
					tallaList.set(i, nuevoDatoDouble);
				}
			}else {
				JOptionPane.showMessageDialog(null, "no encontramos ese nombre");
			}
			}
		

	}

	private void consultarPorNombre() {

		String nombreConsulta = JOptionPane.showInputDialog("Ingrese el nombre a buscar");

		if (nombresList.contains(nombreConsulta)) {
			for (int i = 0; i < nombresList.size(); i++) {
				if (nombresList.get(i).equalsIgnoreCase(nombreConsulta)) {
					System.out.println("Si existe " + nombreConsulta + "," + " tiene " + resultadosList.get(i));
				}
			}

			System.out.println("Imprime usando foreach");
			for (String elemento : nombresList) {
				int pos = nombresList.indexOf(elemento);
				if (nombresList.get(pos).equalsIgnoreCase(nombreConsulta)) {
					System.out.println(elemento + ", resultado= " + resultadosList.get(pos));

				}
			}

		} else {
			System.out.println("NO existe");
		}

	}

	public void imprimirListas() {
		System.out.println("********RESULTADOS**********");
		for (int i = 0; i < nombresList.size(); i++) {
			System.out.println(nombresList.get(i) + ", resultado: " + resultadosList.get(i));
		}
		System.out.println("*****************************");
	}

	private void ingresarDatos() {
		nombre = JOptionPane.showInputDialog("Ingrese el nombre");
		nombresList.add(nombre);
		imc = 0;
		peso = Double.parseDouble(JOptionPane.showInputDialog("Ingrese el peso"));
		pesoList.add(peso);
		talla = Double.parseDouble(JOptionPane.showInputDialog("Ingrese la talla"));
		tallaList.add(talla);

	}

	private void calcularIMC() {
		imc = peso / (talla * talla);
		System.out.println("El IMC es: " + imc);

		String result = "";

		if (imc < 18) {
			result = ("Anorexia");
		} else if (imc >= 18 && imc < 20) {
			result = ("Delgadez");
		} else if (imc >= 20 && imc < 27) {
			result = ("Normalidad");
		} else if (imc >= 27 && imc < 30) {
			result = ("Obesidad 1");
		} else if (imc >= 30 && imc < 35) {
			result = ("Obesidad 2");
		} else if (imc >= 35 && imc < 40) {
			result = ("Obesidad 3");
		} else if (imc >= 40) {
			result = ("Obesidad Morbida");
		}

		resultadosList.add(result);
		System.out.println("El Resultado es: " + result);
	}

}
